package com.example.bikecare.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ServiceRecord::class], version = 1, exportSchema = false)
abstract class BikeDatabase : RoomDatabase() {
    abstract fun serviceDao(): ServiceDao

    companion object {
        @Volatile private var INSTANCE: BikeDatabase? = null

        fun get(context: Context): BikeDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BikeDatabase::class.java,
                    "bike-care.db"
                ).build().also { INSTANCE = it }
            }
    }
}
