package com.example.bikecare.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.bikecare.R

class ReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val language = inputData.getString("language") ?: "en"
        val title = if (language == "gu") "બાઈક સર્વિસ યાદ અપાવવું" else "Bike service reminder"
        val message = if (language == "gu") {
            inputData.getString("messageGu") ?: "તમારી બાઈકની આગામી સર્વિસ તપાસો."
        } else {
            inputData.getString("messageEn") ?: "Check whether your next bike service is due."
        }

        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "bike_service_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    if (language == "gu") "સર્વિસ યાદ અપાવવું" else "Service reminders",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        // Android 13+ requires notification permission. If permission is denied,
        // the worker completes without showing a notification.
        try {
            NotificationManagerCompat.from(applicationContext)
                .notify(inputData.getInt("notificationId", 1001), notification)
        } catch (_: SecurityException) {
            // Permission was not granted; no notification can be shown.
        }
        return Result.success()
    }
}
