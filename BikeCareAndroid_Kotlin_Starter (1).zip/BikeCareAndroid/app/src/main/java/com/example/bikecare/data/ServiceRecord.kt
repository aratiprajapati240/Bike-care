package com.example.bikecare.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_records")
data class ServiceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val serviceDate: String,
    val serviceTime: String,
    val odometerKm: Int,
    val serviceType: String,
    val workDone: String,
    val partsChanged: String,
    val garage: String,
    val costRupees: Double,
    val notes: String,
    val nextServiceDate: String = "",
    val nextServiceKm: Int? = null,
    val reminderScheduled: Boolean = false
)
