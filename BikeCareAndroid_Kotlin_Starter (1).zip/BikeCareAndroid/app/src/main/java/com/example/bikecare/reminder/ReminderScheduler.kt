package com.example.bikecare.reminder

import android.content.Context
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    private val dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    fun schedule(
        context: Context,
        dueDate: String,
        language: String,
        recordId: Long
    ) {
        val date = try {
            LocalDate.parse(dueDate, dateFormatter)
        } catch (_: Exception) {
            return
        }

        // Reminder is scheduled for 9:00 AM local time on the due date.
        val target = LocalDateTime.of(date, LocalTime.of(9, 0))
        val delay = Duration.between(LocalDateTime.now(), target).toMillis().coerceAtLeast(0L)
        val data = Data.Builder()
            .putString("language", language)
            .putString("messageEn", "Your bike service is due today. Open Bike Care to review the record.")
            .putString("messageGu", "આજે તમારી બાઈકની સર્વિસ કરવાની તારીખ છે. વિગતો માટે બાઈક કેર ખોલો.")
            .putInt("notificationId", (recordId % Int.MAX_VALUE).toInt())
            .build()

        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()

        WorkManager.getInstance(context).enqueue(request)
    }
}
