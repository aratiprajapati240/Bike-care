package com.example.bikecare

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.bikecare.data.BikeDatabase
import com.example.bikecare.data.ServiceRecord
import com.example.bikecare.reminder.ReminderScheduler
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val dao = BikeDatabase.get(applicationContext).serviceDao()
        setContent {
            MaterialTheme {
                BikeCareApp(
                    dao = dao,
                    onScheduleReminder = { record, language ->
                        if (record.nextServiceDate.isNotBlank()) {
                            ReminderScheduler.schedule(
                                this,
                                record.nextServiceDate,
                                language,
                                record.id
                            )
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BikeCareApp(
    dao: com.example.bikecare.data.ServiceDao,
    onScheduleReminder: (ServiceRecord, String) -> Unit
) {
    val context = LocalContext.current
    var language by remember { mutableStateOf("en") }
    var showForm by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val records by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val total by dao.observeTotalExpenses().collectAsStateWithLifecycle(initialValue = 0.0)

    val isGu = language == "gu"
    fun tr(en: String, gu: String) = if (isGu) gu else en

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Bike Care | બાઈક કેર", fontWeight = FontWeight.Bold)
                        Text(
                            tr("Service & maintenance tracker", "સર્વિસ અને જાળવણીનો રેકોર્ડ"),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                actions = {
                    TextButton(onClick = { language = if (isGu) "en" else "gu" }) {
                        Text(if (isGu) "English" else "ગુજરાતી")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showForm = true }) {
                Icon(Icons.Default.Add, contentDescription = tr("Add service", "સર્વિસ ઉમેરો"))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr("Total recorded expenses", "કુલ નોંધાયેલ ખર્ચ"), style = MaterialTheme.typography.titleMedium)
                    Text("₹${"%.2f".format(total)}", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        tr("${records.size} service record(s)", "${records.size} સર્વિસ રેકોર્ડ"),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                label = { Text(tr("Search history", "સર્વિસ ઇતિહાસ શોધો")) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            if (records.isEmpty()) {
                Text(
                    tr("No service records yet. Tap + to add your first service.",
                        "હજુ કોઈ સર્વિસ રેકોર્ડ નથી. પ્રથમ સર્વિસ ઉમેરવા + દબાવો."),
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            } else {
                val filtered = records.filter {
                    listOf(
                        it.serviceDate, it.serviceType, it.garage,
                        it.workDone, it.partsChanged, it.notes
                    ).any { field -> field.contains(search, ignoreCase = true) }
                }
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(filtered, key = { it.id }) { record ->
                        ServiceRecordCard(
                            record = record,
                            language = language,
                            onDelete = {
                                // Delete only after user confirms.
                                // Confirmation dialog is displayed by the card.
                            },
                            onConfirmDelete = { lifecycleScopeLaunch(context, dao, record) }
                        )
                    }
                }
            }
        }
    }

    if (showForm) {
        ServiceFormDialog(
            language = language,
            onDismiss = { showForm = false },
            onSave = { record ->
                showForm = false
                (context as? ComponentActivity)?.lifecycleScope?.launch {
                    val id = dao.insert(record)
                    if (record.nextServiceDate.isNotBlank()) {
                        onScheduleReminder(record.copy(id = id), language)
                    }
                }
            }
        )
    }
}

private fun lifecycleScopeLaunch(
    context: android.content.Context,
    dao: com.example.bikecare.data.ServiceDao,
    record: ServiceRecord
) {
    (context as? ComponentActivity)?.lifecycleScope?.launch {
        dao.delete(record)
    }
}

@Composable
private fun ServiceRecordCard(
    record: ServiceRecord,
    language: String,
    onDelete: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    val isGu = language == "gu"
    var askDelete by remember { mutableStateOf(false) }
    fun tr(en: String, gu: String) = if (isGu) gu else en

    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(record.serviceType.ifBlank { tr("Service", "સર્વિસ") }, fontWeight = FontWeight.Bold)
                    Text("${record.serviceDate}  •  ${record.serviceTime}")
                }
                IconButton(onClick = { askDelete = true }) {
                    Icon(Icons.Default.Delete, contentDescription = tr("Delete", "ડિલીટ કરો"))
                }
            }
            Text("${tr("Odometer", "કિલોમીટર")}: ${record.odometerKm} km")
            Text("${tr("Cost", "ખર્ચ")}: ₹${"%.2f".format(record.costRupees)}")
            if (record.garage.isNotBlank()) Text("${tr("Garage", "ગેરેજ")}: ${record.garage}")
            if (record.workDone.isNotBlank()) Text("${tr("Work done", "કરેલું કામ")}: ${record.workDone}")
            if (record.partsChanged.isNotBlank()) Text("${tr("Parts changed", "બદલેલા પાર્ટ્સ")}: ${record.partsChanged}")
            if (record.notes.isNotBlank()) Text("${tr("Notes", "નોંધ")}: ${record.notes}")
            if (record.nextServiceDate.isNotBlank()) {
                Text("${tr("Next service", "આગામી સર્વિસ")}: ${record.nextServiceDate}")
            }
            record.nextServiceKm?.let {
                Text("${tr("Next service at", "આગામી સર્વિસ કિમી")}: $it km")
            }
        }
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text(tr("Delete record?", "રેકોર્ડ ડિલીટ કરવો છે?")) },
            text = { Text(tr("This cannot be undone.", "આ ક્રિયા પાછી ફેરવી શકાશે નહીં.")) },
            confirmButton = {
                TextButton(onClick = {
                    askDelete = false
                    onConfirmDelete()
                }) { Text(tr("Delete", "ડિલીટ કરો")) }
            },
            dismissButton = {
                TextButton(onClick = { askDelete = false }) { Text(tr("Cancel", "રદ કરો")) }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ServiceFormDialog(
    language: String,
    onDismiss: () -> Unit,
    onSave: (ServiceRecord) -> Unit
) {
    val isGu = language == "gu"
    fun tr(en: String, gu: String) = if (isGu) gu else en

    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var time by remember { mutableStateOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))) }
    var odometer by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Regular service") }
    var work by remember { mutableStateOf("") }
    var parts by remember { mutableStateOf("") }
    var garage by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("0") }
    var notes by remember { mutableStateOf("") }
    var nextDate by remember { mutableStateOf("") }
    var nextKm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Add service record", "સર્વિસનો રેકોર્ડ ઉમેરો")) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(tr("Date uses YYYY-MM-DD format. Time uses 24-hour format.", "તારીખ YYYY-MM-DD અને સમય 24-કલાકના ફોર્મેટમાં છે."),
                    style = MaterialTheme.typography.bodySmall)
                Field(date, { date = it }, tr("Service date (YYYY-MM-DD)", "સર્વિસ તારીખ (YYYY-MM-DD)"))
                Field(time, { time = it }, tr("Service time (HH:mm)", "સર્વિસ સમય (HH:mm)"))
                Field(odometer, { odometer = it }, tr("Odometer km *", "ઓડોમીટર કિમી *"), number = true)
                Field(type, { type = it }, tr("Service type", "સર્વિસનો પ્રકાર"))
                Field(work, { work = it }, tr("Work done", "કરેલું કામ"), multiline = true)
                Field(parts, { parts = it }, tr("Parts changed", "બદલેલા પાર્ટ્સ"), multiline = true)
                Field(garage, { garage = it }, tr("Garage / mechanic", "ગેરેજ / મિકેનિક"))
                Field(cost, { cost = it }, tr("Total cost ₹", "કુલ ખર્ચ ₹"), number = true)
                Field(notes, { notes = it }, tr("Notes", "નોંધ"), multiline = true)
                Divider()
                Text(tr("Next service reminder (optional)", "આગામી સર્વિસ યાદ અપાવવું (વૈકલ્પિક)"),
                    fontWeight = FontWeight.SemiBold)
                Field(nextDate, { nextDate = it }, tr("Next service date (YYYY-MM-DD)", "આગામી સર્વિસ તારીખ (YYYY-MM-DD)"))
                Field(nextKm, { nextKm = it }, tr("Next service odometer km", "આગામી સર્વિસ કિમી"), number = true)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val km = odometer.toIntOrNull()
                val parsedCost = cost.toDoubleOrNull()
                val validDate = try { LocalDate.parse(date); true } catch (_: Exception) { false }
                val validTime = try { LocalTime.parse(time); true } catch (_: Exception) { false }
                val validNextDate = nextDate.isBlank() || try { LocalDate.parse(nextDate); true } catch (_: Exception) { false }

                if (!validDate || !validTime || km == null || km < 0 || parsedCost == null || parsedCost < 0 || !validNextDate) {
                    error = tr(
                        "Check date, time, odometer and cost. Use YYYY-MM-DD and HH:mm.",
                        "તારીખ, સમય, કિલોમીટર અને ખર્ચ તપાસો. YYYY-MM-DD અને HH:mm ફોર્મેટ વાપરો."
                    )
                } else {
                    onSave(
                        ServiceRecord(
                            serviceDate = date,
                            serviceTime = time,
                            odometerKm = km,
                            serviceType = type,
                            workDone = work,
                            partsChanged = parts,
                            garage = garage,
                            costRupees = parsedCost,
                            notes = notes,
                            nextServiceDate = nextDate,
                            nextServiceKm = nextKm.toIntOrNull()
                        )
                    )
                }
            }) { Text(tr("Save", "સાચવો")) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(tr("Cancel", "રદ કરો")) }
        }
    )
}

@Composable
private fun Field(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    number: Boolean = false,
    multiline: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = !multiline,
        minLines = if (multiline) 2 else 1
    )
}
