package com.example.bikecare.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceDao {
    @Query("SELECT * FROM service_records ORDER BY serviceDate DESC, serviceTime DESC, id DESC")
    fun observeAll(): Flow<List<ServiceRecord>>

    @Insert
    suspend fun insert(record: ServiceRecord): Long

    @Delete
    suspend fun delete(record: ServiceRecord)

    @Query("SELECT COALESCE(SUM(costRupees), 0) FROM service_records")
    fun observeTotalExpenses(): Flow<Double>
}
