# Bike Care | બાઈક કેર — Android Studio + Kotlin

A native Android starter project for recording bike servicing, costs, repairs, odometer readings, notes, and next-service reminders. The UI labels switch between English and Gujarati. Records are stored locally with Room (SQLite); the app works offline.

## Requirements
- Android Studio (recent stable version)
- JDK 17
- Android SDK 35 (Android Studio can install it)
- Internet on first Gradle sync to download dependencies

## Open and run
1. Extract `BikeCareAndroid.zip`.
2. In Android Studio choose **Open** and select the extracted `BikeCareAndroid` folder.
3. Let Gradle sync and install any SDK components Android Studio requests.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**.

## Build an APK
In Android Studio choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show the output path after a successful build.

## Included
- English/Gujarati interface toggle
- Add service record: date, time, odometer, service type, work done, parts, garage, cost, notes
- Optional next-service date and km
- Room database for local/offline storage
- Search service history
- Total recorded expense summary
- WorkManager due-date notification scheduled for 9:00 AM on the entered date
- Delete record with confirmation

## Important notes
- This is a starter project source ZIP, not a compiled APK. It must be opened, synced, built, and tested in Android Studio.
- Date/time fields accept `YYYY-MM-DD` and `HH:mm` (24-hour format).
- Android 13+ asks for notification permission. If denied, reminders cannot appear.
- WorkManager is designed for reliable deferrable work, not exact-to-the-minute alarms; Android may delay notifications because of battery restrictions.
- Reminders are scheduled for the due date only. Editing/cancelling a reminder, km-based automatic reminders, backup/export, bike profile editing, and notification rescheduling after reboot should be added before treating it as a production app.
- Local database records can be lost if the user clears app data or uninstalls the app. Add an export/restore feature for backup.
- The project uses Android Gradle Plugin 8.7.3, Kotlin 1.9.25, Compose compiler 1.5.15, and Room 2.6.1. If Android Studio proposes a compatible upgrade, review it and sync.

## Build an APK online with GitHub Actions (no Android Studio needed locally)
1. Create a new repository on GitHub.
2. Upload the contents of this project folder to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and select **Build Bike Care APK**.
4. Run the workflow using **Run workflow** if it has not run automatically.
5. When the workflow finishes, open the run and download the `BikeCare-debug-apk` artifact. Extract it to get `app-debug.apk`.
6. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installing apps from that source.

The GitHub workflow is a build path, not an APK itself. The first build must complete successfully before an APK artifact is available.
